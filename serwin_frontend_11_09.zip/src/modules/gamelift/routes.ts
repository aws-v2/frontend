import type { RouteRecordRaw } from 'vue-router'
import { useAuthStore } from '@/modules/auth/store/authStore'

const gameliftRoutes: RouteRecordRaw[] = [
    {
        path: '/gaming',
        name: 'gaming-landing',
        component: () => import('./pages/GamingLandingPage.vue'),
        meta: { requiresAuth: false },
        beforeEnter: (_to, _from, next) => {
            const auth = useAuthStore()
            if (auth.isAuthenticated) {
                next({ name: 'gaming-console' })
            } else {
                next()
            }
        }
    },
    {
        path: '/gaming/console',
        name: 'gaming-console',
        component: () => import('./pages/GamingConsolePage.vue'),
        meta: { requiresAuth: true }
    },
    {
        path: '/gamelift/fleets/create',
        name: 'gamelift-create-fleet',
        component: () => import('./pages/CreateFleetPage.vue'),
        meta: { requiresAuth: true }
    },
    {
        path: '/gamelift/games/:id',
        name: 'gamelift-server',
        component: () => import('./pages/GameLiftServerPage.vue'),
    },
    {
        path: '/gamelift/play/:id',
        name: 'gamelift-play',
        component: () => import('./pages/Game.vue'),
    },

    {
        path: '/gamelift/render-jobs/create',
        name: 'gamelift-render-jobs-create',
        component: () => import('./pages/CreateRenderJobPage.vue'),
    }

]

export default gameliftRoutes
